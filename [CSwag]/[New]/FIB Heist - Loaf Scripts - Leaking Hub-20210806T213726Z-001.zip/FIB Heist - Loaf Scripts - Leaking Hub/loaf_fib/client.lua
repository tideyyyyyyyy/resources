CreateThread(function()
    while not Loaded do
        Wait(0)
    end
    
    ESX['TriggerServerCallback']('loaf_fib:hasaccess', function(has)
        if has then
            local SpawnedObjects, Trolleys, Busy, Locked = {}, {}, false, false
            
            CreateThread(function()
                while not Loaded do
                    Wait(0)
                end
                
                CreateThread(function()
                    Wait(math.random(100, 750))-- in case two people are at the same position, trying to trigger the code at the same time. this *should* prevent double spawning
                    while true do
                        for k, v in pairs(Config['Trolleys']) do
                            if #(GetEntityCoords(PlayerPedId()) - v['coords']) <= 10.0 then
                                Wait(math.random(100, 1500))
                                local empty = false
                                local trolley = GetClosestObjectOfType(v['coords'], 0.3, GetHashKey('hei_prop_hei_cash_trolly_01'), false)
                                if not DoesEntityExist(trolley) then
                                    trolley = GetClosestObjectOfType(v['coords'], 0.3, GetHashKey('hei_prop_hei_cash_trolly_03'), false)
                                    empty = true
                                end
                                if not DoesEntityExist(trolley) then
                                    trolley = CreateObject(LoadModel(GetHashKey('hei_prop_hei_cash_trolly_01')), v['coords'], true)
                                    NetworkRegisterEntityAsNetworked(trolley)
                                    SetNetworkIdCanMigrate(ObjToNet(trolley))
                                    SetNetworkIdExistsOnAllMachines(ObjToNet(trolley))
                                    FreezeEntityPosition(trolley, true)
                                    SetEntityHeading(trolley, v['heading'])
                                    SetEntityAsMissionEntity(trolley, true, true)
                                    Trolleys[k] = {
                                        ['NetID'] = ObjToNet(trolley),
                                        ['Obj'] = trolley,
                                        ['Empty'] = false
                                    }
                                    table.insert(SpawnedObjects, trolley)
                                else
                                    if empty then
                                        Trolleys[k] = {
                                            ['NetID'] = ObjToNet(trolley),
                                            ['Obj'] = trolley,
                                            ['Empty'] = true
                                        }
                                        table.insert(SpawnedObjects, trolley)
                                    else
                                        Trolleys[k] = {
                                            ['NetID'] = ObjToNet(trolley),
                                            ['Obj'] = trolley,
                                            ['Empty'] = false
                                        }
                                    end
                                end
                            end
                        end
                        Wait(4500)
                    end
                end)
                ESX['TriggerServerCallback']('loaf_fib:getLocked', function(stat)
                    Locked = stat
                end)
                CreateThread(function()
                    while true do
                        for k, v in pairs(Trolleys) do
                            v['Obj'] = NetToObj(v['NetID'])
                        end
                        Wait(1000)
                    end
                end)
                while true do
                    local sleep = 500
                    local door = GetClosestObjectOfType(Config['Door']['Coords'], 2.0, GetHashKey(Config['Door']['Obj']))
                    if DoesEntityExist(door) then
                        local dist = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(door))
                        if dist <= 5.0 then
                            FreezeEntityPosition(door, Locked)
                            if Locked then
                                SetEntityHeading(door, Config['Door']['Heading'])
                                if dist <= 3.0 then
                                    sleep = 0
                                    if Config['3DText']['Enabled'] and dist > 1.5 then
                                        HelpText(Strings['LockPick'], GetOffsetFromEntityInWorldCoords(door, Config['Door']['Offset']) + vec3(0.0, 0.0, 1.0))
                                    end
                                    if dist <= 1.5 then
                                        HelpText('~INPUT_CONTEXT~ ' .. Strings['LockPick'], GetOffsetFromEntityInWorldCoords(door, Config['Door']['Offset']) + vec3(0.0, 0.0, 1.0))
                                        if IsControlJustReleased(0, 51) then
                                            if Cops >= Config['RequiredCops'] then
                                                while not HasAnimDictLoaded(Config['Door']['Anim']['Dict']) do
                                                    Wait(0)
                                                    RequestAnimDict(Config['Door']['Anim']['Dict'])
                                                end
                                                TriggerServerEvent('loaf_fib:policeMsg')
                                                SetEntityCoords(PlayerPedId(), GetOffsetFromEntityInWorldCoords(door, Config['Door']['LockPick']))
                                                SetEntityHeading(PlayerPedId(), Config['Door']['LockPickHeading'])
                                                TaskPlayAnim(PlayerPedId(), Config['Door']['Anim']['Dict'], Config['Door']['Anim']['Anim'], 8.0, -8.0, -1, 1, 0, false, false, false)
                                                Wait(Config['Door']['Anim']['Time'])
                                                ClearPedTasks(PlayerPedId())
                                                TriggerServerEvent('loaf_fib:unlockDoor')
                                            else
                                                Notify(Strings['NoCops'])
                                            end
                                        end
                                    end
                                end
                            else
                                if Job == Config['Police'] then
                                    if dist <= 3.0 then
                                        sleep = 0
                                        if Config['3DText']['Enabled'] and dist > 1.5 then
                                            HelpText(Strings['Lock'], GetOffsetFromEntityInWorldCoords(door, Config['Door']['Offset']) + vec3(0.0, 0.0, 1.0))
                                        end
                                        if dist <= 1.5 then
                                            HelpText('~INPUT_CONTEXT~ ' .. Strings['Lock'], GetOffsetFromEntityInWorldCoords(door, Config['Door']['Offset']) + vec3(0.0, 0.0, 1.0))
                                            if IsControlJustReleased(0, 51) then
                                                while not HasAnimDictLoaded(Config['Door']['Anim']['Dict']) do
                                                    Wait(0)
                                                    RequestAnimDict(Config['Door']['Anim']['Dict'])
                                                end
                                                SetEntityCoords(PlayerPedId(), GetOffsetFromEntityInWorldCoords(door, Config['Door']['LockPick']))
                                                SetEntityHeading(PlayerPedId(), Config['Door']['LockPickHeading'])
                                                TaskPlayAnim(PlayerPedId(), Config['Door']['Anim']['Dict'], Config['Door']['Anim']['Anim'], 8.0, -8.0, -1, 1, 0, false, false, false)
                                                Wait(Config['Door']['Anim']['Time'])
                                                ClearPedTasks(PlayerPedId())
                                                TriggerServerEvent('loaf_fib:lockDoor')
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                    if not Busy then
                        for k, v in pairs(Trolleys) do
                            if not v['Empty'] then
                                local dist = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(v['Obj']))
                                if dist <= 3.0 and not Locked then
                                    if Config['3DText']['Enabled'] then
                                        sleep = 0
                                        if dist > 1.0 then
                                            HelpText(Strings['Grab'], GetEntityCoords(v['Obj']) + vec3(0.0, 0.0, 1.0))
                                        end
                                    end
                                    if dist <= 1.0 then
                                        HelpText('~INPUT_CONTEXT~ ' .. Strings['Grab'], GetEntityCoords(v['Obj']) + vec3(0.0, 0.0, 1.0))
                                        if IsControlJustReleased(0, 51) then
                                            GrabCash(v['Obj'], k)
                                        end
                                    end
                                end
                            end
                        end
                    end
                    Wait(sleep)
                end
            end)
            GrabCash = function(trolley, id)
                local total = 0
                Busy = true
                TriggerServerEvent('loaf_fib:removeTrolley', id)
                local plr = PlayerPedId()
                local bag = CreateObject(LoadModel(GetHashKey('hei_p_m_bag_var22_arm_s')), GetEntityCoords(plr), true, false, false)
                table.insert(SpawnedObjects, bag)
                local scene = NetworkCreateSynchronisedScene(GetEntityCoords(trolley), GetEntityRotation(trolley), 2, false, false, 1065353216, 0, 1.3)
                NetworkAddPedToSynchronisedScene(plr, scene, 'anim@heists@ornate_bank@grab_cash', 'intro', 1.5, -4.0, 1, 16, 1148846080, 0)
                NetworkAddEntityToSynchronisedScene(bag, scene, 'anim@heists@ornate_bank@grab_cash', 'bag_intro', 4.0, -8.0, 1)
                NetworkStartSynchronisedScene(scene)
                Wait(1500)
                local cash = CreateObject(LoadModel(GetHashKey('hei_prop_heist_cash_pile')), GetEntityCoords(plr), true)
                FreezeEntityPosition(cash, true)
                SetEntityInvincible(cash, true)
                SetEntityNoCollisionEntity(cash, plr)
                SetEntityVisible(cash, false, false)
                AttachEntityToEntity(cash, plr, GetPedBoneIndex(plr, 60309), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 0, true)
                local stop = GetGameTimer() + 37000
                table.insert(SpawnedObjects, cash)
                CreateThread(function()
                    while GetGameTimer() <= stop do
                        Wait(0)
                        if HasAnimEventFired(plr, GetHashKey('CASH_APPEAR')) then
                            SetEntityVisible(cash, true, false)
                        end
                        if HasAnimEventFired(plr, GetHashKey('RELEASE_CASH_DESTROY')) then
                            if IsEntityVisible(cash) then
                                SetEntityVisible(cash, false, false)
                                total = total + math.random(Config['Cash']['Min'], Config['Cash']['Max'])
                            end
                        end
                    end
                    Notify((Strings['Grabbed']):format(total))
                    TriggerServerEvent('loaf_fib:grabbed', total)
                    DeleteObject(cash)
                    DeleteObject(bag)
                    local coords, rotation = GetOffsetFromEntityInWorldCoords(trolley, 0.0, 0.0, -0.98), GetEntityRotation(trolley)
                    CreateThread(function()
                        while DoesEntityExist(trolley) do
                            Wait(0)
                            while not NetworkHasControlOfEntity(trolley) do
                                Wait(0)
                                NetworkRequestControlOfEntity(trolley)
                            end
                            SetEntityCoords(trolley, 0.0, 0.0, 0.0)
                            SetEntityAsMissionEntity(trolley, true, true)
                            DeleteObject(trolley)
                        end
                    end)
                    Wait(500)
                    local Newtrolley = CreateObject(LoadModel(GetHashKey('hei_prop_hei_cash_trolly_03')), coords, true)
                    PlaceObjectOnGroundProperly(Newtrolley)
                    NetworkRegisterEntityAsNetworked(Newtrolley)
                    SetNetworkIdCanMigrate(ObjToNet(Newtrolley))
                    SetNetworkIdExistsOnAllMachines(ObjToNet(Newtrolley))
                    SetEntityRotation(Newtrolley, rotation)
                    Trolleys[id] = {
                        ['NetID'] = ObjToNet(Newtrolley),
                        ['Obj'] = Newtrolley,
                        ['Empty'] = true
                    }
                    table.insert(SpawnedObjects, Newtrolley)
                    Busy = false
                end)
                scene = NetworkCreateSynchronisedScene(GetEntityCoords(trolley), GetEntityRotation(trolley), 2, false, false, 1065353216, 0, 1.3)
                NetworkAddPedToSynchronisedScene(plr, scene, 'anim@heists@ornate_bank@grab_cash', 'grab', 1.5, -4.0, 1, 16, 1148846080, 0)
                NetworkAddEntityToSynchronisedScene(bag, scene, 'anim@heists@ornate_bank@grab_cash', 'bag_grab', 4.0, -8.0, 1)
                NetworkAddEntityToSynchronisedScene(trolley, scene, 'anim@heists@ornate_bank@grab_cash', 'cart_cash_dissapear', 4.0, -8.0, 1)
                NetworkStartSynchronisedScene(scene)
            end
            AddEventHandler('onResourceStop', function(resourceName)
                if resourceName == GetCurrentResourceName() then
                    for k, v in pairs(SpawnedObjects) do
                        DeleteObject(v)
                    end
                end
            end)
            RegisterNetEvent('loaf_fib:setLocked')
            AddEventHandler('loaf_fib:setLocked', function(stat)
                Locked = stat
            end)
            LoadModel = function(model)
                local Timer = GetGameTimer() + 5000
                while not HasModelLoaded(model) do
                    Wait(0)
                    RequestModel(model)
                    if GetGameTimer() >= Timer then
                        return false
                    end
                end
                return model
            end
            HelpText = function(msg, coords, close)
                if not coords or not Config['3DText']['Enabled'] then
                    AddTextEntry(GetCurrentResourceName(), msg)
                    DisplayHelpTextThisFrame(GetCurrentResourceName(), false)
                else
                    Config['3DText']['Draw'](coords, string.gsub(msg, '~INPUT_CONTEXT~', '~w~[~r~' .. GetControlInstructionalButton(0, 51, 1):gsub('t_', '') .. '~w~]'))
                end
            end
        end
    end)
end)
