Strings = {
    ['Grab'] = 'Grab cash',
    ['Grabbed'] = 'You grabbed ~g~$%s',
    ['LockPick'] = 'Lockpick the door',
    ['Lock'] = 'Lock the door',
    ['NoCops'] = 'There are not enough cops online',
    ['Robbery'] = 'Someone is robbing the FIB!',
    ['Waypoint'] = '~INPUT_CONTEXT~ Set waypoint'
}

Config = {
    ['Door'] = {
        ['Obj'] = 'v_ilev_fib_door2', -- door object
        ['Coords'] = vec3(128.13, -729.37, 241.17), -- door coords
        ['Heading'] = 69.99938694844, -- door heading
        ['Offset'] = vec3(-0.6, 0.0, -0.75), -- offset for the text "lockpick the door"
        ['LockPick'] = vec3(-1.0, 0.7, -1.5), -- offset when locking + unlocking
        ['LockPickHeading'] = 250.0, -- heading when locking + unlocking
        ['Anim'] = {
            ['Dict'] = 'missheistfbisetup1', -- animation dict for locking + unlocking
            ['Anim'] = 'hassle_intro_loop_f', -- animation for locking + unlocking
            ['Time'] = 5000, -- ms before cancelling animation (unlocking door)
        },
    },

    ['Police'] = 'police', -- job name for police (locking the door after robbery + getting cops online)
    ['RequiredCops'] = 0, -- cops required to lockpick the door / grab cash

    ['Cash'] = {
        ['Min'] = 25, -- minimum cash (for each pile)
        ['Max'] = 50, -- max cash (for each pile)
    },

    ['Trolleys'] = {
        {
            ['heading'] = 310.0,
            ['coords'] = vec3(129.89, -726.31, 241.17),
        },
        {
            ['heading'] = 200.0,
            ['coords'] = vec3(130.59, -724.23, 241.17),
        },
        {
            ['heading'] = 158.0,
            ['coords'] = vec3(132.24, -724.56, 241.17),
        },
        {
            ['heading'] = 70.49,
            ['coords'] = vec3(134.46, -726.03, 241.17)
        }
    }
}

Config['3DText'] = {
    ['Enabled'] = true,

    ['Draw'] = function(coords, text)
        SetDrawOrigin(coords)

        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextEntry('STRING')
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(0.0, 0.0)
        DrawRect(0.0, 0.0125, 0.015 + text:gsub("~.-~", ""):len() / 370, 0.03, 45, 45, 45, 150)

        ClearDrawOrigin()
    end
}