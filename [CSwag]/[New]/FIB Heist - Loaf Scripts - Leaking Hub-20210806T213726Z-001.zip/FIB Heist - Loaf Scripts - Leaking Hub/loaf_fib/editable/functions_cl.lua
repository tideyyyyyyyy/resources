Loaded = false
ESX = nil
Job = 'unemployed'
Cops = 0

CreateThread(function()
    
    while ESX == nil do 
        TriggerEvent('esx:getSharedObject', function(obj) 
            ESX = obj 
        end)
        Wait(0) 
    end

    while ESX['GetPlayerData']()['job'] == nil do 
        Wait(0) 
    end

    Loaded = true

    while true do
        Job = ESX['GetPlayerData']()['job']['name']
        ESX['TriggerServerCallback']('loaf_fib:getCops', function(res)
            Cops = res
        end)
        Wait(5000)
    end
end)

Notify = function(msg)
    ESX['ShowNotification'](msg)
end

RegisterNetEvent('loaf_fib:notify')
AddEventHandler('loaf_fib:notify', function()
    Notify(Strings['Robbery'])
    local timer = GetGameTimer() + 7500
    while timer >= GetGameTimer() do 
        Wait(0)
        AddTextEntry(GetCurrentResourceName(), Strings['Robbery'] .. '\n' .. Strings['Waypoint'])
        DisplayHelpTextThisFrame(GetCurrentResourceName(), false)
        if IsControlJustReleased(0, 51) then
            SetNewWaypoint(Config['Door']['Coords']['x'], Config['Door']['Coords']['y'])
            break
        end
    end
end)