ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) 
    ESX = obj 
end)

IsPolice = function(id)
    return (ESX['GetPlayerFromId'](id)['job']['name'] == Config['Police'])
end

ESX['RegisterServerCallback']('loaf_fib:getCops', function(source, cb)
    local xPlayers = ESX['GetPlayers']()
    local cops = 0
    for i = 1, #xPlayers do
        if IsPolice(xPlayers[i]) then
            cops = cops + 1
        end
    end
    cb(cops)
end)

RegisterServerEvent('loaf_fib:grabbed')
AddEventHandler('loaf_fib:grabbed', function(cash)
    local src = source
    local xPlayer = ESX['GetPlayerFromId'](src)
    xPlayer['addMoney'](cash)
end)

RegisterServerEvent('loaf_fib:policeMsg')
AddEventHandler('loaf_fib:policeMsg', function()
    local xPlayers = ESX['GetPlayers']()
    for i = 1, #xPlayers do
        if IsPolice(xPlayers[i]) then
            TriggerClientEvent('loaf_fib:notify', xPlayers[i])
        end
    end
end)