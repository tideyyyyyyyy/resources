--[[-----------------------------------
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
© Loaf Scripts 2020 All Rights Reserved
Leaking Hub | J. Snow | leakinghub.com
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
--]]-----------------------------------

fx_version 'adamant'

game 'gta5'

server_scripts {
	'editable/functions_sv.lua',
	'server.lua',
	'editable/config.lua',
}

client_scripts {
	'editable/functions_cl.lua',
	'client.lua',
	'editable/config.lua'
}