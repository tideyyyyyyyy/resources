

ESX['RegisterServerCallback']('loaf_fib:hasaccess', function(source, cb)
	cb(true)
end)

ESX['RegisterServerCallback']('loaf_fib:getLocked', function(source, cb)
	cb(locked)
end)

RegisterServerEvent('loaf_fib:setFrozen')
AddEventHandler('loaf_fib:setFrozen', function(status)
	frozen = status
	TriggerCleitnEvent('loaf_fib:updateDoor', -1, frozen)
end)

RegisterServerEvent('loaf_fib:unlockDoor')
AddEventHandler('loaf_fib:unlockDoor', function()
	locked = false
	TriggerClientEvent('loaf_fib:setLocked', -1, locked)
end)

RegisterServerEvent('loaf_fib:lockDoor')
AddEventHandler('loaf_fib:lockDoor', function()
	local src = source
	if IsPolice(src) then
		locked = true
		TriggerClientEvent('loaf_fib:setLocked', -1, locked)
	end
end)