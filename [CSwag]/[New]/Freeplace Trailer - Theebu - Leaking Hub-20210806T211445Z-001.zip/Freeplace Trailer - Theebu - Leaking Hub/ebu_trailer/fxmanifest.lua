fx_version 'adamant'
game 'gta5'

description 'EBU Trailer'

version '0.3.0'

-- Leaking Hub | J. Snow | leakinghub.com

client_scripts {
	'config.lua',
	'client/client.lua'
}

server_scripts {
	'server/server.lua'
}
