Hi, thank you for buying my script!

1. Edit config.lua to your liking.

If you don't have the okokNotify script you need to change the notifications on client.lua and on server.lua.

And you are ready to go :)

If you need help contact me on discord: okok#3488
My discord server: https://discord.gg/FauTgGRUku