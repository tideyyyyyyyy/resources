INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('iron', 'Iron', 25),
	('steel', 'Steel', 25),
	('copper',' Copper', 25),
	('emerald', 'Emerald', 5),
	('diamond', 'Diamond', 5),
;