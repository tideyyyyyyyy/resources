# 19/01/2020
Fixed locking other mods up due to disableControls loop.