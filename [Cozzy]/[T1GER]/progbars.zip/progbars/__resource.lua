-- Found on: https://modit.store
-- ModFreakz Discord: https://discord.gg/4S7FcFs

resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

ui_page 'index.html'

client_scripts {
  'client.lua',
} 

files {
  'index.html',
  'MarvelRegular-Dj83.TTF',
}

exports {
  'StartProg',
  'CloseProg',
}